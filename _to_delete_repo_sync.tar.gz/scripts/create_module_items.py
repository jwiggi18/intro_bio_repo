#!/usr/bin/env python3
"""
create_module_items.py — Create Canvas module structure for BIOL 1113.

For each of the 15 weeks this script will:
  1. Create (or find existing) a Canvas module named "Week NN: Topic Title"
  2. Set the module's unlock date to Monday morning of that week
  3. Add the three wiki pages (Overview, Materials, Assignments) as module items
     in the correct order

Pages must already exist in Canvas before running this script.
Run upload_to_canvas.py first to create the wiki pages.

Usage:
  python3 scripts/create_module_items.py           # all 15 weeks
  python3 scripts/create_module_items.py 1         # single week
  python3 scripts/create_module_items.py 1 4       # week range (inclusive)

Requirements:
  - .env with CANVAS_TOKEN, CANVAS_BASE_URL, CANVAS_COURSE_ID
  - Pages already uploaded via upload_to_canvas.py

Requires Python 3.8+. Standard library only.
"""

import sys
import os
import json
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).parent.parent

# ── Course week data ────────────────────────────────────────────────────────
# (week_num, topic, unlock_date_iso)
# Unlock = Monday 6:00 AM Central → 11:00 AM UTC (CDT, UTC-5)

WEEKS = [
    ( 1, "Learning and the Nature of Science",       "2026-08-17T11:00:00Z"),
    ( 2, "Biological Molecules",                      "2026-08-24T11:00:00Z"),
    ( 3, "Cells and Biological Organization",         "2026-08-31T11:00:00Z"),
    ( 4, "Biological Membranes and Cell Signaling",   "2026-09-07T11:00:00Z"),
    ( 5, "DNA and Genetic Variation",                 "2026-09-14T11:00:00Z"),
    ( 6, "Gene Expression",                           "2026-09-21T11:00:00Z"),
    ( 7, "Cell Division",                             "2026-09-28T11:00:00Z"),
    ( 8, "Inheritance",                               "2026-10-05T11:00:00Z"),
    ( 9, "Evolution and Natural Selection",           "2026-10-12T11:00:00Z"),
    (10, "Population Genetics and Speciation",        "2026-10-19T11:00:00Z"),
    (11, "Cellular Respiration",                      "2026-10-26T11:00:00Z"),
    (12, "Photosynthesis",                            "2026-11-02T11:00:00Z"),
    (13, "Biological Systems",                        "2026-11-09T11:00:00Z"),
    (14, "Ecosystems",                                "2026-11-16T11:00:00Z"),
    (15, "Human Impacts on Biological Systems",       "2026-11-30T11:00:00Z"),
]

# One page per module — slug matches upload_to_canvas.py pattern
PAGE_SUFFIXES = [
    ("Week Content", "week"),
]


# ── .env / config ──────────────────────────────────────────────────────────

def load_env():
    env_path = ROOT / ".env"
    if not env_path.exists():
        print("Error: .env file not found.")
        print("Copy .env.example to .env and fill in your Canvas credentials.")
        sys.exit(1)
    env = {}
    for line in env_path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        if '=' in line:
            key, _, val = line.partition('=')
            env[key.strip()] = val.strip()
    return env


def get_config():
    env = load_env()
    required = ['CANVAS_TOKEN', 'CANVAS_BASE_URL', 'CANVAS_COURSE_ID']
    missing = [k for k in required if not env.get(k) or 'your_' in env.get(k, '')]
    if missing:
        print(f"Error: Missing or unfilled values in .env: {', '.join(missing)}")
        sys.exit(1)
    return env


# ── Canvas API helpers ─────────────────────────────────────────────────────

def canvas_request(method, path, token, base_url, data=None):
    url = f"{base_url.rstrip('/')}/api/v1/{path.lstrip('/')}"
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json',
    }
    body = json.dumps(data).encode('utf-8') if data else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        body_text = e.read().decode('utf-8')
        print(f"  HTTP {e.code} on {method} {url}")
        print(f"  Response: {body_text[:400]}")
        raise


def get_all_modules(token, base_url, course_id):
    """Return all modules as a dict keyed by name."""
    modules = canvas_request('GET', f'courses/{course_id}/modules?per_page=100',
                             token, base_url)
    return {m['name']: m for m in modules}


def get_module_items(module_id, token, base_url, course_id):
    """Return existing module items as a list."""
    return canvas_request('GET',
        f'courses/{course_id}/modules/{module_id}/items?per_page=100',
        token, base_url)


def page_slug(week_num, suffix):
    """Match the slug Canvas assigns when upload_to_canvas.py uploads weekNN/suffix.html.
    upload_to_canvas.py strips the build/biol1113/ prefix, so the slug is weekNN-suffix."""
    return f"week{week_num:02d}-{suffix}"


# ── Per-week logic ─────────────────────────────────────────────────────────

def upsert_module(week_num, topic, unlock_date, existing_modules,
                  token, base_url, course_id):
    """Create the module if it doesn't exist; return module dict."""
    name = f"Week {week_num:02d}: {topic}"

    if name in existing_modules:
        module = existing_modules[name]
        print(f"  [exists]  Module: {name}")
        return module

    module = canvas_request('POST', f'courses/{course_id}/modules', token, base_url, {
        'module': {
            'name': name,
            'position': week_num,
            'unlock_at': unlock_date,
            'published': False,
        }
    })
    print(f"  [created] Module: {name}  (unlocks {unlock_date})")
    return module


def add_page_item(module_id, title, slug, position, token, base_url, course_id):
    """Add a wiki page as a module item."""
    canvas_request('POST',
        f'courses/{course_id}/modules/{module_id}/items',
        token, base_url,
        {
            'module_item': {
                'title': title,
                'type': 'Page',
                'page_url': slug,
                'position': position,
            }
        })
    print(f"    + {title}")


def process_week(week_num, topic, unlock_date, existing_modules,
                 token, base_url, course_id):
    module = upsert_module(week_num, topic, unlock_date, existing_modules,
                           token, base_url, course_id)
    module_id = module['id']

    # Get items already in this module to avoid duplicates
    existing_items = get_module_items(module_id, token, base_url, course_id)
    existing_titles = {item['title'] for item in existing_items}

    position = len(existing_items) + 1
    for _label, suffix in PAGE_SUFFIXES:
        title = f"Week {week_num:02d} - {topic}"
        if title in existing_titles:
            print(f"    ~ {title} (already present, skipped)")
            continue
        slug = page_slug(week_num, suffix)
        add_page_item(module_id, title, slug, position, token, base_url, course_id)
        position += 1


# ── Main ───────────────────────────────────────────────────────────────────

def parse_week_range():
    """Parse optional CLI args: none=all, one arg=single week, two args=range."""
    args = sys.argv[1:]
    if not args:
        return list(range(1, 16))
    elif len(args) == 1:
        n = int(args[0])
        return [n]
    elif len(args) == 2:
        return list(range(int(args[0]), int(args[1]) + 1))
    else:
        print("Usage: create_module_items.py [start_week [end_week]]")
        sys.exit(1)


def main():
    config = get_config()
    token     = config['CANVAS_TOKEN']
    base_url  = config['CANVAS_BASE_URL']
    course_id = config['CANVAS_COURSE_ID']

    target_weeks = parse_week_range()
    week_data = {num: (topic, unlock) for num, topic, unlock in WEEKS}

    print(f"Fetching existing modules from Canvas course {course_id}...")
    existing_modules = get_all_modules(token, base_url, course_id)
    print(f"Found {len(existing_modules)} existing module(s).\n")

    for week_num in target_weeks:
        if week_num not in week_data:
            print(f"  SKIP  Week {week_num} — not in WEEKS table")
            continue
        topic, unlock_date = week_data[week_num]
        print(f"Week {week_num:02d}: {topic}")
        process_week(week_num, topic, unlock_date, existing_modules,
                     token, base_url, course_id)
        print()

    print("Done.")
    print("Modules created as drafts. Publish them in Canvas when ready.")


if __name__ == '__main__':
    main()
