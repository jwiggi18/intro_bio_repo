#!/usr/bin/env python3
"""
create_declaration_quizzes.py — Create blog comment declaration quizzes
for BIOL 1113 (Weeks 2–15) via the Canvas API.

Each quiz is identical in structure:
  - Q1 (10 pts): True/False — student affirms they completed two comments
  - Q2 (0 pts): Short answer — URL of blog post they commented on (1 of 2)
  - Q3 (0 pts): Short answer — URL of blog post they commented on (2 of 2)

Each quiz is created as an unpublished draft. Before publishing each week,
open it in Canvas and replace the [PLACEHOLDER] instructions with the
week-specific context.

Usage:
  python3 scripts/create_declaration_quizzes.py

Requirements:
  - .env with CANVAS_TOKEN, CANVAS_BASE_URL, CANVAS_COURSE_ID
  - Standard library only (no pip installs)
"""

import sys
import os
import json
import urllib.request
import urllib.error
from pathlib import Path

ROOT = Path(__file__).parent.parent


# ---------------------------------------------------------------------------
# Week data — weeks 2–15 (blog posts / comment declarations)
# ---------------------------------------------------------------------------

WEEKS = [
    ( 2, "August 24–30",           "Biological Molecules"),
    ( 3, "August 31–September 6",  "Cells and Biological Organization"),
    ( 4, "September 7–13",         "Biological Membranes and Cell Signaling"),
    ( 5, "September 14–20",        "DNA and Genetic Variation"),
    ( 6, "September 21–27",        "Gene Expression"),
    ( 7, "September 28–October 4", "Cell Division"),
    ( 8, "October 5–11",           "Inheritance"),
    ( 9, "October 12–18",          "Evolution and Natural Selection"),
    (10, "October 19–25",          "Population Genetics and Speciation"),
    (11, "October 26–November 1",  "Cellular Respiration"),
    (12, "November 2–8",           "Photosynthesis"),
    (13, "November 9–15",          "Biological Systems"),
    (14, "November 16–22",         "Ecosystems"),
    (15, "November 23–29",         "Human Impacts on Biological Systems"),
]

# Blog comment declarations reference the PRIOR week's blog post topic.
# Week 2 declaration = comments on Week 1 posts (Week 1 has no blog post,
# so adjust if needed — leave the placeholder clear for instructor to fill).


def quiz_description(week_num, week_dates, topic):
    """
    Returns the HTML description/instructions for one quiz.
    The [PLACEHOLDER] section is what the instructor fills in before publishing.
    """
    prior_week = week_num - 1
    return f"""<p><strong>Week {week_num} Blog Comment Declaration</strong> &middot; Due Sunday, {week_dates.split('–')[-1].strip()}, 2026 at 11:59 PM</p>

<hr />

<p><strong>What this quiz is for:</strong> This quiz confirms that you completed your two required blog comments this week. It is not graded on the quality of your answers here &mdash; it is graded on whether you actually completed the comments on your classmates' blogs.</p>

<p><strong>Before you submit this quiz:</strong></p>
<ul>
  <li>You must have left a substantive comment (3&ndash;5+ sentences) on two different classmates' blog posts from Week {prior_week}.</li>
  <li>You must have used the <a href="/courses/COURSE_ID/pages/blog-directory">Blog Directory randomizer</a> to find your assigned blogs.</li>
  <li>Your comments must be visible on your classmates' blogs (not just drafted).</li>
</ul>

<p><strong>[PLACEHOLDER &mdash; Week {week_num} specific instructions]</strong><br />
Before publishing this quiz, replace this paragraph with any week-specific context. For example: what the blog posts were about, any special commenting guidance for this week's topic ({topic}), or reminders relevant to this week's content.
</p>

<p style="color: #57606a; font-size: 18px;"><em>Blog comments are spot-checked. Submitting this declaration falsely is an academic integrity violation.</em></p>"""


# ---------------------------------------------------------------------------
# .env loader + Canvas API helpers (same pattern as other scripts)
# ---------------------------------------------------------------------------

def load_env():
    env_path = ROOT / ".env"
    if not env_path.exists():
        print("Error: .env file not found. Copy .env.example to .env and fill in credentials.")
        sys.exit(1)
    env = {}
    for line in env_path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        if '=' in line:
            key, _, val = line.partition('=')
            env[key.strip()] = val.strip()
    return env


def get_config():
    env = load_env()
    required = ['CANVAS_TOKEN', 'CANVAS_BASE_URL', 'CANVAS_COURSE_ID']
    missing = [k for k in required if not env.get(k) or 'your_' in env.get(k, '')]
    if missing:
        print(f"Error: Missing or unfilled values in .env: {', '.join(missing)}")
        sys.exit(1)
    return env


def canvas_request(method, path, token, base_url, data=None):
    url = f"{base_url.rstrip('/')}/api/v1/{path.lstrip('/')}"
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json',
    }
    body = json.dumps(data).encode('utf-8') if data else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        err_body = e.read().decode('utf-8')
        print(f"  HTTP {e.code} on {method} {url}")
        print(f"  {err_body[:400]}")
        raise


# ---------------------------------------------------------------------------
# Quiz + question creation
# ---------------------------------------------------------------------------

def create_quiz(week_num, week_dates, topic, token, base_url, course_id):
    """Create one declaration quiz and its three questions. Returns quiz id."""
    title = f"Blog Comment Declaration — Week {week_num:02d}"
    description = quiz_description(week_num, week_dates, topic)

    quiz_payload = {
        'quiz': {
            'title': title,
            'description': description,
            'quiz_type': 'assignment',         # graded quiz
            'points_possible': 10,
            'allowed_attempts': 2,             # two attempts in case of error
            'published': False,                # draft — publish when ready
            'show_correct_answers': False,
            'shuffle_answers': False,
            'time_limit': None,
        }
    }

    quiz = canvas_request(
        'POST',
        f'courses/{course_id}/quizzes',
        token, base_url,
        quiz_payload
    )
    quiz_id = quiz['id']

    # Q1: True/False affirmation — worth all 10 points
    canvas_request('POST', f'courses/{course_id}/quizzes/{quiz_id}/questions', token, base_url, {
        'question': {
            'question_name': 'Completion Declaration',
            'question_text': (
                f'I have left a substantive comment (3–5+ sentences) on <strong>two different</strong> '
                f'classmates&rsquo; blog posts from Week {week_num - 1}. '
                f'Both comments are publicly visible on their blogs. '
                f'I found my assigned blogs using the Blog Directory randomizer.'
            ),
            'question_type': 'true_false_question',
            'points_possible': 10,
            'answers': [
                {'text': 'True',  'weight': 100},
                {'text': 'False', 'weight': 0},
            ],
        }
    })

    # Q2: URL of first blog post commented on — 0 pts, for verification
    canvas_request('POST', f'courses/{course_id}/quizzes/{quiz_id}/questions', token, base_url, {
        'question': {
            'question_name': 'Blog URL 1',
            'question_text': (
                'Paste the full URL of the <strong>first</strong> blog post you commented on '
                '(the URL of the specific post, not just the blog homepage).'
            ),
            'question_type': 'short_answer_question',
            'points_possible': 0,
        }
    })

    # Q3: URL of second blog post commented on — 0 pts, for verification
    canvas_request('POST', f'courses/{course_id}/quizzes/{quiz_id}/questions', token, base_url, {
        'question': {
            'question_name': 'Blog URL 2',
            'question_text': (
                'Paste the full URL of the <strong>second</strong> blog post you commented on '
                '(the URL of the specific post, not just the blog homepage).'
            ),
            'question_type': 'short_answer_question',
            'points_possible': 0,
        }
    })

    return quiz_id, title


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    cfg = get_config()
    token     = cfg['CANVAS_TOKEN']
    base_url  = cfg['CANVAS_BASE_URL']
    course_id = cfg['CANVAS_COURSE_ID']

    print(f"Creating {len(WEEKS)} declaration quizzes in course {course_id}...\n")

    created = []
    for week_num, week_dates, topic in WEEKS:
        try:
            quiz_id, title = create_quiz(week_num, week_dates, topic, token, base_url, course_id)
            print(f"  [created] {title}  (id: {quiz_id})")
            created.append((week_num, quiz_id, title))
        except Exception as e:
            print(f"  [error]   Week {week_num}: {e}")

    print(f"\nDone. {len(created)}/{len(WEEKS)} quizzes created as unpublished drafts.")
    print("\nNext steps:")
    print("  1. In Canvas > Assignments, find the 14 'Blog Comment Declaration' quizzes.")
    print("  2. Before publishing each week's quiz, open it and replace the")
    print("     [PLACEHOLDER] paragraph with that week's specific instructions.")
    print("  3. Set the due date and add it to the correct week's module.")
    print("  4. Publish when you're ready for students to see it.")


if __name__ == '__main__':
    main()
