"""
canvas_targets.py — non-secret per-course configuration for the multi-course
BIOL 1113 build.

This repo now feeds more than one Canvas course: the "sandbox" (the
template course other instructors will import to teach the course), any
"live" course(s) taught directly from this repo before the sandbox is fully
built out, or in future semesters, and the "hybrid" course (lecture + GTA-led
small group, no blog posts/comments — its content genuinely differs from
sandbox/live, not just its Canvas ids; see content_root below). Only a
handful of course-specific values differ per target, listed below.

Safe to commit -- no credentials live here. The Canvas API token stays in
.env (gitignored) and is looked up separately by upload_to_canvas.py.

Each target needs:
  - course_id: the Canvas course ID. None means "not set up yet" -- build
    and upload scripts will refuse to run against a target with no id.
  - base_url: the Canvas instance (kept per-target in case that's ever not
    the same across courses; today it always is).
  - content_root: where this target's source HTML lives, relative to the
    repo root. Omit (or use ".") for the default — root-level *.html plus
    week01-week15/week.html, the layout sandbox/live share. Set to a
    subfolder name (e.g. "hybrid") when a target's content is genuinely
    different, not just a different Canvas id — that subfolder must mirror
    the same layout (homepage.html, syllabus.html, weekNN/week.html).
  - learning_notes_ids: that course's own Learning Notes assignment ids,
    one per week (1-15). These are NOT shared across courses -- Canvas
    assigns a fresh id to every assignment in every course, even when it
    was copied from another course via import. Run
    `python3 scripts/create_learning_notes_group.py <target>` to create
    its Learning Notes assignments, then paste the resulting ids in here.
  - small_group_ids: same idea as learning_notes_ids, but for the "Small
    Group Participation" assignment group (hybrid course only — sandbox/live
    don't have this category, so they omit the key entirely). Run
    `python3 scripts/create_small_group_group.py <target>` to create its
    Small Group Participation assignments, then paste the resulting ids in
    here.
  - chart_image_url: that course's own hosted copy of the syllabus grade
    donut chart PNG. Also NOT shared across courses -- Canvas files belong
    to one course each. None means "not uploaded to this course yet" --
    the syllabus build will leave {{CHART_IMAGE_URL}} unresolved (visibly
    broken) until this is filled in. Run
    scripts/upload_chart_to_canvas.py against a course to upload it, then
    paste the resulting URL in here.

To add a new target (a new semester's section, another instructor's course,
etc.): copy one of the blocks below, fill in the course_id, run
`create_learning_notes_group.py <target>` (and `create_small_group_group.py
<target>`, for hybrid) and `upload_chart_to_canvas.py <target>` against it,
and fill in the resulting ids / chart_image_url. Nothing else in the repo
needs to change -- every script here takes the target name as its first
argument.
"""

TARGETS = {
    "sandbox": {
        "course_id": "215536",
        "base_url": "https://canvas.okstate.edu",
        "learning_notes_ids": {
            1: 2673768, 2: 2673769, 3: 2673770, 4: 2673771, 5: 2673772,
            6: 2673773, 7: 2673774, 8: 2673775, 9: 2673776, 10: 2673777,
            11: 2673778, 12: 2673779, 13: 2673780, 14: 2673781, 15: 2673782,
        },
        "chart_image_url": "https://canvas.okstate.edu/files/26482456/download?download_frd=1&verifier=o5RBhzPh7ATKKQ21Nv2txPsoFmEhjTW3mzmDRv3Q",
    },

    "live": {
        "course_id": "238411",
        "base_url": "https://canvas.okstate.edu",
        "learning_notes_ids": {
            1: 2678256, 2: 2678257, 3: 2678258, 4: 2678259, 5: 2678260,
            6: 2678261, 7: 2678262, 8: 2678263, 9: 2678264, 10: 2678265,
            11: 2678266, 12: 2678267, 13: 2678268, 14: 2678269, 15: 2678270,
        },
        "chart_image_url": "https://canvas.okstate.edu/files/26482457/download?download_frd=1&verifier=NQHKoLhs2nukRk0uc3VtzXzsAJ39FvB1N3FG5trv",
    },

    # Hybrid: lecture (Mon, NRC 106, 3:30-4:20) + GTA-led small group
    # (Claudia Goss) replacing Blog Posts/Blog Comments. Content genuinely
    # differs from sandbox/live (first video slot each week becomes a
    # lecture notice, no blog assignment links, Small Group Participation
    # link instead) — see content_root and hybrid/ in the repo. Course id
    # 239593 confirmed by Jodie Aug 13, 2026. learning_notes_ids and
    # learning_notes_ids and small_group_ids populated Aug 13, 2026 by running
    #   python3 scripts/create_learning_notes_group.py hybrid
    #   python3 scripts/create_small_group_group.py hybrid
    # against course 239593. All 30 assignments created as unpublished drafts.
    "hybrid": {
        "course_id": "239593",
        "base_url": "https://canvas.okstate.edu",
        "content_root": "hybrid",
        "learning_notes_ids": {
            1: 2690603, 2: 2690604, 3: 2690605, 4: 2690606, 5: 2690607,
            6: 2690608, 7: 2690609, 8: 2690610, 9: 2690611, 10: 2690612,
            11: 2690613, 12: 2690614, 13: 2690615, 14: 2690616, 15: 2690617,
        },
        "small_group_ids": {
            1: 2690618, 2: 2690619, 3: 2690620, 4: 2690621, 5: 2690622,
            6: 2690623, 7: 2690624, 8: 2690625, 9: 2690626, 10: 2690627,
            11: 2690628, 12: 2690629, 13: 2690630, 14: 2690631, 15: 2690632,
        },
        "chart_image_url": "https://canvas.okstate.edu/files/26527152/download?download_frd=1&verifier=51e6d4b4-6b92-42f5-b66d-ebe796210997",
    },
}


def get_target(name):
    """Look up a target by name, with a clear error if it's missing or
    not fully configured yet."""
    if name not in TARGETS:
        valid = ", ".join(sorted(TARGETS))
        raise SystemExit(f"Error: unknown target '{name}'. Valid targets: {valid}")
    t = TARGETS[name]
    if not t.get("course_id"):
        raise SystemExit(
            f"Error: target '{name}' has no course_id set yet -- "
            f"fill it in in canvas_targets.py before building or uploading to it."
        )
    return t
